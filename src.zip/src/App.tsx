import React, { useState, useEffect } from 'react';
import { Filter } from 'lucide-react';
import Header from './components/Layout/Header';
import RestaurantCard from './components/Restaurant/RestaurantCard';
import DishCard from './components/Restaurant/DishCard';
import Cart from './components/Cart/Cart';
import AuthModal from './components/Auth/AuthModal';
import Checkout from './components/Checkout/Checkout';
import AdminDashboard from './components/Admin/AdminDashboard';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import { mockRestaurants, mockDishes } from './data/mockData';
import { Restaurant, Dish } from './types';

function AppContent() {
  const { user } = useAuth();
  const [view, setView] = useState<'restaurants' | 'restaurant-detail' | 'admin'>('restaurants');
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [filteredRestaurants, setFilteredRestaurants] = useState(mockRestaurants);
  const [filteredDishes, setFilteredDishes] = useState<Dish[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState('');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [orderComplete, setOrderComplete] = useState<string | null>(null);

  // Get unique cuisines for filtering
  const cuisines = Array.from(new Set(mockRestaurants.flatMap(r => r.cuisine)));

  useEffect(() => {
    let filtered = mockRestaurants;

    if (searchQuery) {
      filtered = filtered.filter(restaurant =>
        restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        restaurant.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        restaurant.cuisine.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    if (selectedCuisine) {
      filtered = filtered.filter(restaurant =>
        restaurant.cuisine.includes(selectedCuisine)
      );
    }

    setFilteredRestaurants(filtered);
  }, [searchQuery, selectedCuisine]);

  useEffect(() => {
    if (selectedRestaurant) {
      let dishes = mockDishes.filter(dish => dish.restaurantId === selectedRestaurant.id);
      
      if (searchQuery) {
        dishes = dishes.filter(dish =>
          dish.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          dish.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          dish.category.toLowerCase().includes(searchQuery.toLowerCase())
        );
      }
      
      setFilteredDishes(dishes);
    }
  }, [selectedRestaurant, searchQuery]);

  const handleRestaurantClick = (restaurant: Restaurant) => {
    setSelectedRestaurant(restaurant);
    setView('restaurant-detail');
  };

  const handleBackToRestaurants = () => {
    setSelectedRestaurant(null);
    setView('restaurants');
    setSearchQuery('');
  };

  const handleOrderComplete = (orderId: string) => {
    setOrderComplete(orderId);
    setTimeout(() => setOrderComplete(null), 5000);
  };

  // Show admin dashboard for admin users
  if (user?.role === 'admin' && view === 'admin') {
    return <AdminDashboard />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        onAuthClick={() => setIsAuthModalOpen(true)}
        onCartClick={() => setIsCartOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Admin Access */}
      {user?.role === 'admin' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => setView(view === 'admin' ? 'restaurants' : 'admin')}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors"
          >
            {view === 'admin' ? 'Back to Store' : 'Admin Dashboard'}
          </button>
        </div>
      )}

      {/* Order Success Message */}
      {orderComplete && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg">
            <p className="font-medium">Order placed successfully!</p>
            <p className="text-sm">Order ID: {orderComplete}</p>
          </div>
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {view === 'restaurants' ? (
          <>
            {/* Hero Section */}
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Delicious food, delivered fast
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Order from your favorite restaurants and get your food delivered in minutes
              </p>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap items-center gap-4 mb-8">
              <div className="flex items-center space-x-2">
                <Filter className="h-5 w-5 text-gray-600" />
                <span className="text-sm font-medium text-gray-700">Filter by cuisine:</span>
              </div>
              <select
                value={selectedCuisine}
                onChange={(e) => setSelectedCuisine(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="">All Cuisines</option>
                {cuisines.map(cuisine => (
                  <option key={cuisine} value={cuisine}>{cuisine}</option>
                ))}
              </select>
              {(searchQuery || selectedCuisine) && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCuisine('');
                  }}
                  className="text-sm text-orange-600 hover:text-orange-700"
                >
                  Clear filters
                </button>
              )}
            </div>

            {/* Restaurants Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredRestaurants.map((restaurant) => (
                <RestaurantCard
                  key={restaurant.id}
                  restaurant={restaurant}
                  onClick={() => handleRestaurantClick(restaurant)}
                />
              ))}
            </div>

            {filteredRestaurants.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-600 text-lg">No restaurants found matching your criteria.</p>
              </div>
            )}
          </>
        ) : view === 'restaurant-detail' && selectedRestaurant ? (
          <>
            {/* Restaurant Header */}
            <div className="mb-8">
              <button
                onClick={handleBackToRestaurants}
                className="text-orange-600 hover:text-orange-700 mb-4 flex items-center space-x-2"
              >
                <span>← Back to restaurants</span>
              </button>
              
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="relative h-64 md:h-80">
                  <img
                    src={selectedRestaurant.image}
                    alt={selectedRestaurant.name}
                    className="w-full h-full object-cover"
                  />
                  {!selectedRestaurant.isOpen && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <span className="text-white font-semibold text-2xl">Currently Closed</span>
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h1 className="text-3xl font-bold text-gray-900 mb-2">{selectedRestaurant.name}</h1>
                      <p className="text-gray-600 mb-4">{selectedRestaurant.description}</p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {selectedRestaurant.cuisine.map((cuisine) => (
                          <span
                            key={cuisine}
                            className="px-3 py-1 bg-orange-100 text-orange-600 text-sm font-medium rounded-full"
                          >
                            {cuisine}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-1 mb-2">
                        <span className="text-2xl">⭐</span>
                        <span className="text-xl font-bold">{selectedRestaurant.rating}</span>
                      </div>
                      <p className="text-sm text-gray-600">{selectedRestaurant.deliveryTime}</p>
                      <p className="text-sm text-gray-600">${selectedRestaurant.deliveryFee} delivery</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Dishes */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Menu</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredDishes.map((dish) => (
                  <DishCard key={dish.id} dish={dish} />
                ))}
              </div>

              {filteredDishes.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-600 text-lg">No dishes found matching your search.</p>
                </div>
              )}
            </div>
          </>
        ) : null}
      </main>

      {/* Modals */}
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />
      <Checkout
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onOrderComplete={handleOrderComplete}
      />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
import React, { useState } from 'react';
import { Plus, Minus, Star, Leaf, Flame } from 'lucide-react';
import { Dish } from '../../types';
import { useCart } from '../../contexts/CartContext';

interface DishCardProps {
  dish: Dish;
}

const DishCard: React.FC<DishCardProps> = ({ dish }) => {
  const { addToCart, items, updateQuantity } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [showDetails, setShowDetails] = useState(false);

  const existingItem = items.find(item => item.dish.id === dish.id);
  const currentQuantity = existingItem?.quantity || 0;

  const handleAddToCart = () => {
    addToCart(dish, quantity);
    setQuantity(1);
  };

  const handleIncrement = () => {
    if (currentQuantity > 0) {
      updateQuantity(dish.id, currentQuantity + 1);
    } else {
      setQuantity(prev => prev + 1);
    }
  };

  const handleDecrement = () => {
    if (currentQuantity > 0) {
      updateQuantity(dish.id, currentQuantity - 1);
    } else if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
      <div className="relative h-48 overflow-hidden">
        <img
          src={dish.image}
          alt={dish.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-3 left-3 flex space-x-2">
          {dish.isVegetarian && (
            <div className="bg-green-500 rounded-full p-1">
              <Leaf className="h-3 w-3 text-white" />
            </div>
          )}
          {dish.isSpicy && (
            <div className="bg-red-500 rounded-full p-1">
              <Flame className="h-3 w-3 text-white" />
            </div>
          )}
        </div>
        <div className="absolute top-3 right-3">
          <div className="bg-white rounded-full px-2 py-1 flex items-center space-x-1">
            <Star className="h-4 w-4 text-yellow-400 fill-current" />
            <span className="text-sm font-medium text-gray-700">{dish.rating}</span>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-gray-900">{dish.name}</h3>
          <span className="text-lg font-bold text-orange-600">${dish.price}</span>
        </div>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{dish.description}</p>

        <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
          <span className="bg-gray-100 px-2 py-1 rounded-full">{dish.category}</span>
          <span>{dish.preparationTime}</span>
        </div>

        {currentQuantity > 0 ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={handleDecrement}
                className="w-8 h-8 rounded-full bg-gray-200 hover:bg-gray-300 flex items-center justify-center transition-colors"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="font-semibold text-lg">{currentQuantity}</span>
              <button
                onClick={handleIncrement}
                className="w-8 h-8 rounded-full bg-orange-500 hover:bg-orange-600 text-white flex items-center justify-center transition-colors"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <span className="text-sm text-gray-600">In cart</span>
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-8 h-8 rounded-full bg-gray-200 hover:bg-gray-300 flex items-center justify-center transition-colors"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="font-semibold text-lg">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-8 h-8 rounded-full bg-orange-500 hover:bg-orange-600 text-white flex items-center justify-center transition-colors"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <button
              onClick={handleAddToCart}
              className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
            >
              Add to Cart
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DishCard;
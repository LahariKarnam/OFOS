import React, { useState } from 'react';
import { BarChart3, Users, ShoppingBag, DollarSign, Plus, Edit, Trash2 } from 'lucide-react';
import { mockRestaurants, mockDishes } from '../../data/mockData';
import { Restaurant, Dish } from '../../types';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [restaurants, setRestaurants] = useState(mockRestaurants);
  const [dishes, setDishes] = useState(mockDishes);

  const stats = [
    { icon: DollarSign, label: 'Total Revenue', value: '$12,483', change: '+12.5%' },
    { icon: ShoppingBag, label: 'Total Orders', value: '1,234', change: '+8.2%' },
    { icon: Users, label: 'Active Users', value: '8,492', change: '+15.3%' },
    { icon: BarChart3, label: 'Restaurants', value: restaurants.length.toString(), change: '+2.1%' },
  ];

  const toggleRestaurantStatus = (id: string) => {
    setRestaurants(prev =>
      prev.map(restaurant =>
        restaurant.id === id ? { ...restaurant, isOpen: !restaurant.isOpen } : restaurant
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage your food delivery platform</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <stat.icon className="h-6 w-6 text-orange-600" />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm font-medium text-green-600">{stat.change}</span>
                <span className="text-sm text-gray-600 ml-1">vs last month</span>
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'restaurants', label: 'Restaurants' },
                { id: 'dishes', label: 'Dishes' },
                { id: 'orders', label: 'Orders' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-orange-500 text-orange-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-gray-50 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Orders</h3>
                    <div className="space-y-3">
                      {[1, 2, 3].map((order) => (
                        <div key={order} className="flex items-center justify-between bg-white p-3 rounded-lg">
                          <div>
                            <p className="font-medium text-gray-900">Order #ORD-{1000 + order}</p>
                            <p className="text-sm text-gray-600">Bella Italia • $28.50</p>
                          </div>
                          <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                            Delivered
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Restaurants</h3>
                    <div className="space-y-3">
                      {restaurants.slice(0, 3).map((restaurant) => (
                        <div key={restaurant.id} className="flex items-center justify-between bg-white p-3 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <img
                              src={restaurant.image}
                              alt={restaurant.name}
                              className="w-10 h-10 object-cover rounded-lg"
                            />
                            <div>
                              <p className="font-medium text-gray-900">{restaurant.name}</p>
                              <p className="text-sm text-gray-600">{restaurant.rating} ⭐</p>
                            </div>
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            ${Math.floor(Math.random() * 1000 + 500)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'restaurants' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Manage Restaurants</h3>
                  <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2">
                    <Plus className="h-4 w-4" />
                    <span>Add Restaurant</span>
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Restaurant</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cuisine</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {restaurants.map((restaurant) => (
                        <tr key={restaurant.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <img className="h-12 w-12 rounded-lg object-cover" src={restaurant.image} alt={restaurant.name} />
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{restaurant.name}</div>
                                <div className="text-sm text-gray-500">{restaurant.description}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {restaurant.cuisine.join(', ')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {restaurant.rating} ⭐
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <button
                              onClick={() => toggleRestaurantStatus(restaurant.id)}
                              className={`px-2 py-1 text-xs font-medium rounded-full ${
                                restaurant.isOpen
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-red-100 text-red-800'
                              }`}
                            >
                              {restaurant.isOpen ? 'Open' : 'Closed'}
                            </button>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div className="flex space-x-2">
                              <button className="text-orange-600 hover:text-orange-900">
                                <Edit className="h-4 w-4" />
                              </button>
                              <button className="text-red-600 hover:text-red-900">
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'dishes' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Manage Dishes</h3>
                  <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2">
                    <Plus className="h-4 w-4" />
                    <span>Add Dish</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {dishes.map((dish) => (
                    <div key={dish.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
                      <img src={dish.image} alt={dish.name} className="w-full h-48 object-cover" />
                      <div className="p-4">
                        <h4 className="font-medium text-gray-900">{dish.name}</h4>
                        <p className="text-sm text-gray-600 mt-1">{dish.description}</p>
                        <div className="flex justify-between items-center mt-3">
                          <span className="text-lg font-bold text-orange-600">${dish.price}</span>
                          <div className="flex space-x-2">
                            <button className="text-orange-600 hover:text-orange-800">
                              <Edit className="h-4 w-4" />
                            </button>
                            <button className="text-red-600 hover:text-red-800">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'orders' && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Order Management</h3>
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((order) => (
                    <div key={order} className="bg-white border rounded-lg p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h4 className="font-semibold text-gray-900">Order #ORD-{1000 + order}</h4>
                          <p className="text-sm text-gray-600">John Doe • john@example.com</p>
                        </div>
                        <select className="text-sm border border-gray-300 rounded px-3 py-1">
                          <option>Pending</option>
                          <option>Confirmed</option>
                          <option>Preparing</option>
                          <option>Out for Delivery</option>
                          <option>Delivered</option>
                        </select>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">2 items • Bella Italia</span>
                        <span className="font-semibold text-gray-900">${(Math.random() * 50 + 20).toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;